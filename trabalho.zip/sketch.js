let snake;
let food;
let score = 0;
let cellSize = 25;
let cols;
let rows;
let highscore = 0;

// Estados do jogo: 'start', 'playing', 'gameOver'
let gameState = 'start'; // O jogo começa na tela de início

// Paleta de cores para um visual moderno
let colors = {
  backgroundStart: '#1a242f', // Azul escuro carvão mais claro para o topo
  backgroundEnd: '#0a0d10', // Azul escuro carvão quase preto para a base
  gridLine: '#34495e', // Azul carvão um pouco mais claro para as linhas da grade
  snakeHead: '#2ecc71', // Verde esmeralda brilhante
  snakeBodyStart: '#27ae60', // Verde médio para o corpo (início do gradiente)
  snakeBodyEnd: '#1abc9c', // Verde água para o corpo (fim do gradiente)
  foodCenter: '#e74c3c', // Vermelho brilhante
  foodOuter: '#c0392b', // Vermelho escuro para a borda da comida
  text: '#ecf0f1', // Cinza claro quase branco
  buttonHover: '#3498db', // Azul para efeito de hover em botão (exemplo futuro)
  particle: 'rgba(236, 240, 241, 0.4)', // Cor das partículas (branco translúcido, mais visível)
  nebula: 'rgba(52, 73, 94, 0.1)', // Cor para a nebulosa (azul carvão bem transparente)
};

// Variáveis para controlar a animação na tela de início/fim de jogo
let startScreenSnake;
let startScreenFood;
let gameOverTransitionAlpha = 0; // Para o efeito de fade/desaturação
const GAME_OVER_FADE_SPEED = 5; // Velocidade do efeito de fade (maior valor = mais rápido)

// Variáveis para as partículas no fundo
let particles = [];
const NUM_PARTICLES = 200; // Aumentamos o número de partículas

// Variáveis para a animação da cobrinha na tela de início
let startSnakePath = [];
let pathIndex = 0;
let pathLength = 50; // Quantos segmentos no caminho
let pathSpeed = 0.5; // Velocidade da animação do caminho

function setup() {
  createCanvas(650, 650);
  frameRate(10); // Velocidade do jogo

  cols = floor(width / cellSize);
  rows = floor(height / cellSize);

  // Inicializa as instâncias das classes. Elas serão resetadas em restartGame()
  snake = new Snake();
  food = new Food();
  food.spawn();

  // Inicializa cobrinha e comida para a tela de início/fim de jogo UMA VEZ
  startScreenSnake = new Snake();
  startScreenFood = new Food();
  startScreenFood.spawn(); // Posiciona a comida para a tela de início

  // Inicializa as partículas
  for (let i = 0; i < NUM_PARTICLES; i++) {
    particles.push(new Particle());
  }

  // Define um caminho inicial para a cobrinha na tela de start
  // Exemplo: um movimento em forma de S ou curva suave
  for (let i = 0; i < pathLength; i++) {
    let x = map(i, 0, pathLength - 1, width / 4, width * 3 / 4) + sin(i * 0.2) * 50;
    let y = map(i, 0, pathLength - 1, height / 2 - 50, height / 2 + 50);
    startSnakePath.push(createVector(x, y));
  }

  // No início, paramos o loop para exibir a tela de start estaticamente
  noLoop();
}

function draw() {
  // Fundo com gradiente dinâmico
  drawGradientBackground();

  // Desenha as partículas sempre, pois são parte do fundo animado
  for (let particle of particles) {
    particle.update();
    particle.show();
  }

  // Adiciona uma "nebulosa" sutil ao fundo
  drawNebula();

  // Lógica principal do jogo baseada no estado
  if (gameState === 'start') {
    displayStartScreen(); // Exibe a tela de início
  } else if (gameState === 'playing') {
    drawGrid(); // Desenha a grade apenas durante o jogo
    snake.update();
    snake.show();
    food.show();

    // Verifica colisão. Se ocorrer, muda o estado para iniciar a transição
    if (snake.checkCollision()) {
      gameState = 'gameOver'; // Muda o estado
      gameOverTransitionAlpha = 0; // Inicia o efeito do zero
    }

    if (snake.eats(food)) {
      score++;
      food.spawn();
    }
    displayScore(); // Exibe a pontuação apenas durante o jogo
  } else if (gameState === 'gameOver') {
    // Desenha o último estado do jogo por baixo
    drawGrid();
    snake.show();
    food.show();
    displayScore();

    // Aplica o efeito visual de transição
    // Aumenta a opacidade para escurecer a tela e/ou desaturar
    gameOverTransitionAlpha = min(gameOverTransitionAlpha + GAME_OVER_FADE_SPEED, 255);

    // Efeito de overlay escurecido
    fill(0, 0, 0, gameOverTransitionAlpha * 0.6); // 60% da opacidade total
    rect(0, 0, width, height);

    // Efeito de desaturação (opcional, pode ser pesado para GPUs mais antigas)
    // CUIDADO: Este filtro afeta TUDO que é desenhado DEPOIS dele.
    // drawingContext.filter = 'grayscale(' + map(gameOverTransitionAlpha, 0, 255, 0, 100) + '%)';

    // Quando o efeito de transição estiver completo, exibe a tela de Game Over
    if (gameOverTransitionAlpha >= 255) {
      displayGameOver();
      noLoop(); // Para o loop principal para economizar CPU
    }
  }
}

function keyPressed() {
  if (gameState === 'start') {
    gameState = 'playing';
    restartGame(); // Reinicia o jogo para garantir que a cobrinha comece do zero
    loop(); // Retoma o loop quando o jogo começa
  } else if (gameState === 'playing') {
    if (keyCode === UP_ARROW) {
      snake.setDir(0, -1);
    } else if (keyCode === DOWN_ARROW) {
      snake.setDir(0, 1);
    } else if (keyCode === LEFT_ARROW) {
      snake.setDir(-1, 0);
    } else if (keyCode === RIGHT_ARROW) {
      snake.setDir(1, 0);
    }
  } else if (gameState === 'gameOver') {
    // Só reinicia se o efeito de transição já terminou e a tela está totalmente visível
    if (keyCode === 32 && gameOverTransitionAlpha >= 255) { // Spacebar
      restartGame();
      loop(); // Retoma o loop quando o jogo reinicia
    }
  }
}

// --- Funções para Telas ---

function displayStartScreen() {
  // Salva o estado atual da matriz de transformação
  push();

  // Aplica uma escala pulsante para todos os elementos da tela inicial
  let scaleFactor = 1 + sin(frameCount * 0.03) * 0.01; // De 0.99 a 1.01
  translate(width / 2, height / 2);
  scale(scaleFactor);
  translate(-width / 2, -height / 2);

  drawGrid(); // Desenha a grade de fundo na tela de início também

  // Atualiza e mostra a cobrinha animada no caminho
  pathIndex = (pathIndex + pathSpeed) % pathLength;
  let currentPos = startSnakePath[floor(pathIndex)];
  let prevPos = startSnakePath[floor(max(0, pathIndex - 1))];

  // Determina a direção baseada no movimento ao longo do caminho
  let dirX = currentPos.x - prevPos.x;
  let dirY = currentPos.y - prevPos.y;

  // Recria o corpo da cobrinha ao longo do caminho
  startScreenSnake.body = [];
  for (let i = 0; i < startScreenSnake.len; i++) {
    let segmentIndex = floor(pathIndex - i);
    if (segmentIndex < 0) segmentIndex += pathLength; // Loop back
    startScreenSnake.body.push(startSnakePath[segmentIndex].copy());
  }
  startScreenSnake.show();

  // Posiciona a comida perto da cabeça da cobrinha (ou em um ponto fixo no caminho)
  let foodPosIndex = floor(pathIndex + 10) % pathLength; // Comida um pouco à frente
  startScreenFood.x = startSnakePath[foodPosIndex].x;
  startScreenFood.y = startSnakePath[foodPosIndex].y;
  startScreenFood.show();

  // Título do jogo com brilho/pulso de cor
  let brightnessPulse = map(sin(frameCount * 0.05), -1, 1, 0.7, 1.0); // De 70% a 100% de brilho
  let textColor = color(colors.text);
  textColor.setAlpha(map(sin(frameCount * 0.1) * 0.5 + 0.5, 0, 1, 150, 255)); // Pulso de opacidade
  fill(textColor);
  textSize(60);
  textAlign(CENTER, CENTER);
  text('COBRINHA!', width / 2, height / 2 - 170);

  // Subtítulo
  textSize(20);
  fill(colors.text);
  text('O desafio da Maçã Verde', width / 2, height / 2 - 130);

  // Instruções
  textSize(28);
  fill(colors.text);
  text('Use as SETAS para Mover', width / 2, height / 2 - 50);
  text('Coma a Comida para Crescer', width / 2, height / 2);
  text('Não Bata nas Paredes nem em Você!', width / 2, height / 2 + 50);

  // Mensagem para iniciar com efeito de pulso
  textSize(24);
  fill(colors.snakeHead);
  let pulse = sin(frameCount * 0.2) * 8 + 28;
  textSize(pulse);
  text('Pressione QUALQUER TECLA para COMEÇAR', width / 2, height - 80);

  // Restaura o estado da matriz de transformação
  pop();
}

function displayGameOver() {
  // Texto "GAME OVER!"
  fill(colors.text);
  textSize(60);
  textAlign(CENTER, CENTER);
  // Efeito de pulso para o "FIM DE JOGO!"
  let pulse = sin(frameCount * 0.1) * 10 + 60;
  textSize(pulse);
  text('FIM DE JOGO!', width / 2, height / 2 - 50);

  // Pontuação final
  textSize(30);
  fill(colors.text);
  text('Sua Pontuação: ' + score, width / 2, height / 2 + 20);

  // Mensagem para reiniciar
  textSize(20);
  fill(colors.snakeHead);
  text('Pressione ESPAÇO para Reiniciar', width / 2, height / 2 + 70);
}

// --- Funções Auxiliares ---

// Novo: Fundo com Gradiente
function drawGradientBackground() {
  let c1 = color(colors.backgroundStart);
  let c2 = color(colors.backgroundEnd);
  for (let y = 0; y < height; y++) {
    let inter = map(y, 0, height, 0, 1);
    let c = lerpColor(c1, c2, inter);
    stroke(c);
    line(0, y, width, y);
  }
}

// Novo: Nebulosa Sutil
function drawNebula() {
  noStroke();
  fill(colors.nebula);
  // Desenha várias elipses grandes e suaves para criar um efeito de nuvem
  ellipse(width * 0.2, height * 0.3, 150 + sin(frameCount * 0.02) * 20, 120);
  ellipse(width * 0.8, height * 0.6, 200 + cos(frameCount * 0.03) * 25, 180);
  ellipse(width * 0.5, height * 0.1, 100 + sin(frameCount * 0.01) * 15, 80);
  ellipse(width * 0.1, height * 0.8, 120 + cos(frameCount * 0.04) * 18, 90);
}

function drawGrid() {
  stroke(colors.gridLine);
  strokeWeight(1);
  for (let i = 0; i < cols; i++) {
    line(i * cellSize, 0, i * cellSize, height);
  }
  for (let j = 0; j < rows; j++) {
    line(0, j * cellSize, width, j * cellSize);
  }
}

function displayScore() {
  fill(colors.text);
  textSize(24);
  textAlign(LEFT, TOP);
  text('Pontos: ' + score, 15, 15);
  textAlign(RIGHT, TOP);
  text('Recorde: ' + highscore, width - 15, 15);
}

function restartGame() {
  score = 0;
  snake = new Snake(); // Reinicia a cobrinha para o centro
  food.spawn(); // Posiciona nova comida
  gameState = 'playing'; // Volta para o estado 'playing'
  gameOverTransitionAlpha = 0; // Reseta o contador para o próximo game over
}

// --- Particle Class ---
class Particle {
  constructor() {
    this.x = random(width);
    this.y = random(height);
    this.size = random(3, 8); // Partículas um pouco maiores
    this.speedX = random(-0.3, 0.3);
    this.speedY = random(-0.3, 0.3);
    this.alpha = random(100, 255); // Mais visíveis
  }

  update() {
    this.x += this.speedX;
    this.y += this.speedY;
    this.alpha -= 0.8; // Diminui a opacidade mais lentamente

    // Se a partícula sair da tela ou ficar muito transparente, reposiciona
    if (this.alpha <= 0 || this.x < -this.size || this.x > width + this.size || this.y < -this.size || this.y > height + this.size) {
      this.x = random(width);
      this.y = random(height);
      this.alpha = random(100, 255);
      this.size = random(3, 8);
      this.speedX = random(-0.3, 0.3);
      this.speedY = random(-0.3, 0.3);
    }
  }

  show() {
    noStroke();
    fill(red(colors.particle), green(colors.particle), blue(colors.particle), this.alpha);
    ellipse(this.x, this.y, this.size);
  }
}

// --- Snake Class ---
class Snake {
  constructor() {
    this.body = [];
    this.len = 1;
    this.x = floor(cols / 2) * cellSize;
    this.y = floor(rows / 2) * cellSize;
    this.xdir = 0;
    this.ydir = 0;
    this.body.push(createVector(this.x, this.y));
  }

  setDir(x, y) {
    if ((this.xdir === -x && x !== 0) || (this.ydir === -y && y !== 0)) {
      return;
    }
    this.xdir = x;
    this.ydir = y;
  }

  update() {
    // A cobrinha só se move se o jogo estiver no estado 'playing' E se houver direção definida
    if (gameState !== 'playing' || (this.xdir === 0 && this.ydir === 0)) {
      return;
    }

    let head = this.body[this.body.length - 1].copy();
    head.x += this.xdir * cellSize;
    head.y += this.ydir * cellSize;

    this.body.push(head);

    while (this.body.length > this.len) {
      this.body.shift();
    }
  }

  show() {
    for (let i = 0; i < this.body.length; i++) {
      let segment = this.body[i];

      // Desenha a sombra
      fill(0, 0, 0, 80);
      noStroke();
      rect(segment.x + 3, segment.y + 3, cellSize, cellSize, 8);

      // Desenha o corpo da cobrinha com gradiente
      let lerpAmt = map(i, 0, this.body.length - 1, 0, 1);
      let bodyColor = lerpColor(color(colors.snakeBodyStart), color(colors.snakeBodyEnd), lerpAmt);
      fill(bodyColor);
      stroke(colors.gridLine);
      strokeWeight(1);
      rect(segment.x, segment.y, cellSize, cellSize, 8);

      // Desenha a cabeça com uma cor diferente e um brilho
      if (i === this.body.length - 1) {
        drawingContext.filter = 'drop-shadow(0px 0px 8px ' + colors.snakeHead + ')';
        fill(colors.snakeHead);
        rect(segment.x, segment.y, cellSize, cellSize, 8);
        drawingContext.filter = 'none'; // Reseta o filtro para não afetar outros elementos
      }
    }
  }

  eats(food) {
    let head = this.body[this.body.length - 1];
    let d = dist(head.x, head.y, food.x, food.y);
    if (d < 1) {
      this.len++;
      return true;
    }
    return false;
  }

  checkCollision() {
    let head = this.body[this.body.length - 1];

    if (head.x < 0 || head.x >= width || head.y < 0 || head.y >= height) {
      return true;
    }

    for (let i = 0; i < this.body.length - 1; i++) {
      let segment = this.body[i];
      let d = dist(head.x, head.y, segment.x, segment.y);
      if (d < 1) {
        return true;
      }
    }
    return false;
  }
}

// --- Food Class ---
class Food {
  constructor() {
    this.x;
    this.y;
    this.shadowOffset = 5;
  }

  spawn() {
    let newX, newY;
    let collisionWithSnake;
    do {
      newX = floor(random(cols)) * cellSize;
      newY = floor(random(rows)) * cellSize;
      collisionWithSnake = false;
      for (let i = 0; i < snake.body.length; i++) {
        let segment = snake.body[i];
        if (dist(newX, newY, segment.x, segment.y) < 1) {
          collisionWithSnake = true;
          break;
        }
      }
    } while (collisionWithSnake);

    this.x = newX;
    this.y = newY;
  }

  show() {
    // Desenha a sombra da comida
    fill(0, 0, 0, 80);
    noStroke();
    ellipse(this.x + cellSize / 2 + this.shadowOffset, this.y + cellSize / 2 + this.shadowOffset, cellSize * 0.7, cellSize * 0.7);

    // Desenha a comida com gradiente e borda
    let gradient = drawingContext.createRadialGradient(
      this.x + cellSize / 2, this.y + cellSize / 2, 0,
      this.x + cellSize / 2, this.y + cellSize / 2, cellSize / 2
    );
    gradient.addColorStop(0, colors.foodCenter);
    gradient.addColorStop(1, colors.foodOuter);

    drawingContext.fillStyle = gradient;
    drawingContext.strokeStyle = colors.foodOuter;
    drawingContext.lineWidth = 2;
    ellipse(this.x + cellSize / 2, this.y + cellSize / 2, cellSize * 0.8);

    // Resetar estilos do drawingContext para não afetar outros elementos
    drawingContext.fillStyle = 'black';
    drawingContext.strokeStyle = 'black';
    drawingContext.lineWidth = 1;
  }
}